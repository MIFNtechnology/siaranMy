# Changelog For Get_User_Agent

## `v0.1.1`

### 18.05.2022

### Updated

- This changelog
- Updatd to Get_User_Agent 0.1.1
- Updated Crate Name to `Get_User_Agent` in accordance with https://crates.io requirements.


## `v0.1.1`

### 18.05.2022

- Updatd to User_Agent 0.1.0
- Improved upgrade code to be faster and more clean
- Immediately fail if rate limit error occured

### Added

- This changelog
- Error codes

### Changed

- Commented code better
