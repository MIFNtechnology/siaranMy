fn main() {
    let x = 3.14;
    let _y = 1_f64 / x;
}
