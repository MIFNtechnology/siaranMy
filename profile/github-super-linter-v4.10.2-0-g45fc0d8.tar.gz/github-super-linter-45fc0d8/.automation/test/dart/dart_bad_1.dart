// empty_constructor_bodies bad {}
class Point {
  int x, y;
  Point(this.x, this.y) {}
}
