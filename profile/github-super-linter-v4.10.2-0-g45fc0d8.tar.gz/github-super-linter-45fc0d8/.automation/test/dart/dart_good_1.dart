// empty_constructor_bodies good ;
class Point {
  int x, y;
  Point(this.x, this.y);
}
