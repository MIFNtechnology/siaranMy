DELETE from person WHERE 1=1;
