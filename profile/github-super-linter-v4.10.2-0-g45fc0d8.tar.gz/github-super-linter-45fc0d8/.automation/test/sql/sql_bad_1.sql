DELETE from person;
