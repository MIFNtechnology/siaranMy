import pkg.PkgClass
import java.JavaClass

fun main(str1: String, str2: String, str3: String) {
    val j = JavaClass()
    val p = PkgClass()

    println(p)
}
