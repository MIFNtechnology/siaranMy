# Visual Studio Code dev container configuration

This file specifies to Visual Studio Code how to run a [dev container](https://code.visualstudio.com/docs/remote/containers).

For format details, see [documentation](https://code.visualstudio.com/docs/remote/devcontainerjson-reference).
