<!-- markdownlint-disable -->
---
name: Issue Template
about: Used for creating issues about the GitHub Super-Linter

---

---
### Issue with GitHub Super-Linter

---
**Branch/Version:** Example: main

---
**How to Reproduce:** Example: tried to build it

---
**Expected Behavior:** Example: It should have worked

---
**Additional Details:** Example: only happens half past midnight
<!-- markdownlint-restore -->
